package com.ort.fineart.Api_Handel;

public class All_URL {


    //Producation
    //public final static String BASE_URL="http://www.thefinearthub.com/";


    //uat
    public final static String BASE_URL="http://www.thefinearthub.com/";

    public final static String imgURL="http://www.thefinearthub.com";
    public final static String login=BASE_URL+"Customer_Backend/login/?&";
    public final static String register=BASE_URL+"Customer_Backend/add_customer/";
    public final static String bottom_baneer_list="banner_master_backend/get_published_bottombanner_list/";
    public final static String testimonial_list="testimonial_master_backend/get_published_customer_testimonials_list";
    public final static String top_banner_list="banner_master_backend/get_published_topbanner_list/";
    public final static String Product_List="product_master_backend/get_published_product_list/";
    public final static String Category_List="catlogue_master_backend/get_category_list/";
    public final static String PERSONAL_DETAILS="Customer_Backend/getcustomer/";
    public final static String dotd_List="product_master_backend/dealoftheday_product_list/";
    public final static String Best_Seller_List ="product_master_backend/bestseller_product_list/";
    public final static String viewProduct ="product_master_backend/get_varient_details/";
    public final static String vairentList ="product_master_backend/get_varient_details_by_CSI/";
    public final static String addwishlist ="/Customer_Backend/add_and_remove_item_to_wishlist/";
    public final static String addtocart ="Customer_Backend/add_item_to_cart/";
    public final static String Allproductlist ="product_master_backend/All_Product_list/";
    public final static String orderHistoryList ="Customer_Backend/get_customer_order_history/";
    public final static String productListbyCategory ="product_master_backend/get_varients_by_category/";
}
